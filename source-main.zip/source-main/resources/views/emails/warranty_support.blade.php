<h1>Thông tin hỗ trợ</h1>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Thông tin sản phẩm</strong> {{ $data['productName'] }}</p>
<p><strong>Nội dung chi tiết </strong> {{ $data['requestPurpose'] }}</p>
