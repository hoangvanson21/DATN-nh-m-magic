<!DOCTYPE html>
<html>
<head>
    <title>Xác Minh Email</title>
</head>
<body>
    <h1>Xác Minh Địa Chỉ Email</h1>
    <p>Chào bạn,</p>
    <p>Vui lòng nhấp vào liên kết dưới đây để xác minh địa chỉ email của bạn:</p>
    <p>
        <a href="{{ $verificationUrl }}" style="text-decoration: none; color: #1a73e8;">
            Xác Minh Email Ngay
        </a>
    </p>
    <p>Nếu bạn không thực hiện yêu cầu này, vui lòng bỏ qua email này.</p>
    <p>Trân trọng,<br>Đội ngũ hỗ trợ</p>
</body>
</html>
