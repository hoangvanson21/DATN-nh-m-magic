import Swal from 'sweetalert2';
import { message } from 'antd';

message.config({
    top: 100, // Khoảng cách từ trên cùng
    duration: 2, // Thời gian hiển thị (tính bằng giây)
    maxCount: 3, // Số lượng thông báo tối đa cùng lúc
});
